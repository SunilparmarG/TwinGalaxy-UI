export { default } from './Heading';
